"use client";

import { Box, Typography, Paper, Stack, Button } from "@mui/material";

export default function ShowScheduling() {
  return (
    <Box p={4}>
      <Typography variant="h4" fontWeight="bold" mb={4}>
        🎬 Show Scheduling
      </Typography>

     
    </Box>
  );
}
