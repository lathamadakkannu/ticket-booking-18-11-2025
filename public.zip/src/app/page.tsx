"use client";

import Dashboard from './Dashboard/page';

export default function Page() {
  return <Dashboard />;
}
