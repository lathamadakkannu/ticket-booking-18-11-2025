"use client";

import React from "react";
import {
  Modal,
  Box,
  Typography,
  IconButton,
  Paper,
} from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";

interface CommonModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  children: React.ReactNode;
  maxWidth?: string;
}

export default function ModalBox({
  open,
  onClose,
  title,
  children,
  maxWidth = "800px",
}: CommonModalProps) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      className="flex items-center justify-center p-4"
    >
      <Paper
        className="rounded-2xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto"
        style={{ maxWidth, width: "100%" }}
      >
        {/* Modal Header */}
        <Box className="flex items-center justify-between mb-6">
          <Typography className="font-bold text-2xl text-gray-900">
            {title}
          </Typography>
          <IconButton
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <CloseIcon />
          </IconButton>
        </Box>

        {/* Modal Content */}
        <Box>{children}</Box>
      </Paper>
    </Modal>
  );
}